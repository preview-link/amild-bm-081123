(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bm = function() {
	this.initialize(img.bm);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,750);


(lib.bolong = function() {
	this.initialize(img.bolong);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,100,65);


(lib.BukanMain03 = function() {
	this.initialize(img.BukanMain03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,360);


(lib.BukanMain04 = function() {
	this.initialize(img.BukanMain04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,360);


(lib.BukanMain05 = function() {
	this.initialize(img.BukanMain05);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,360);


(lib.BukanMain07 = function() {
	this.initialize(img.BukanMain07);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,360);


(lib.BukanMain08 = function() {
	this.initialize(img.BukanMain08);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,360);


(lib.BukanMain09 = function() {
	this.initialize(img.BukanMain09);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,360);


(lib.BukanMain11 = function() {
	this.initialize(img.BukanMain11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,360);


(lib.BukanMain13 = function() {
	this.initialize(img.BukanMain13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,360);


(lib.CTAcopy = function() {
	this.initialize(img.CTAcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,908,277);


(lib.t1a = function() {
	this.initialize(img.t1a);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t1b = function() {
	this.initialize(img.t1b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t1c = function() {
	this.initialize(img.t1c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t1d = function() {
	this.initialize(img.t1d);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t1e = function() {
	this.initialize(img.t1e);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t1f = function() {
	this.initialize(img.t1f);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t2a = function() {
	this.initialize(img.t2a);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t2b = function() {
	this.initialize(img.t2b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t2c = function() {
	this.initialize(img.t2c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t2d = function() {
	this.initialize(img.t2d);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t3a = function() {
	this.initialize(img.t3a);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t3b = function() {
	this.initialize(img.t3b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t3c = function() {
	this.initialize(img.t3c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t3d = function() {
	this.initialize(img.t3d);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t4a = function() {
	this.initialize(img.t4a);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t4b = function() {
	this.initialize(img.t4b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t4c = function() {
	this.initialize(img.t4c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t5a = function() {
	this.initialize(img.t5a);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t5b = function() {
	this.initialize(img.t5b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t5c = function() {
	this.initialize(img.t5c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t5d = function() {
	this.initialize(img.t5d);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t6a = function() {
	this.initialize(img.t6a);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t6b = function() {
	this.initialize(img.t6b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t6c = function() {
	this.initialize(img.t6c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.t6d = function() {
	this.initialize(img.t6d);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.tangan1 = function() {
	this.initialize(img.tangan1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.tangan2 = function() {
	this.initialize(img.tangan2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,663);


(lib.Tween33 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t6a();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t6b();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween31 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t6c();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t6d();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tangan2();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t5a();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t5b();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t5c();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t5d();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t4a();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t4b();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t4c();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t3b();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t3c();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t3d();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t3a();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tangan1();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#040202").s().p("AA0A5QgHgFgDgJQgDgKAAgMIAAgoQAAgNADgKQADgJAHgFQAIgFANAAQAMAAAIAEQAHAEADAIQAEAIAAALIAAAGIgWAAIAAgGIAAgKQgBgFgDgCQgCgCgGAAQgFAAgDADQgDADAAAEIgBAKIAAAyQAAAHABAFQABAEADADQADACAFAAQAFAAADgDQADgCABgFQACgFAAgHIAAgLIgOAAIAAgNIAhAAIAAA9IgOAAIgCgMQgCAGgFAEQgFADgIAAQgMAAgHgFgAkUA5QgIgEgEgJQgDgJAAgNIAAgsQAAgMADgJQAEgJAIgFQAHgEANAAQANAAAIAEQAHAFAEAJQADAJAAAMIAAAtQAAAMgDAJQgEAIgHAFQgIAFgNAAQgNAAgHgFgAkIgrQgCADgCAEIAAAJIAAA3IAAAJQABAEADADQADACAFAAQAFAAADgCQADgDABgEIABgJIAAg3IgBgJQgBgEgDgDQgDgCgFAAQgFAAgDACgALMA9IAAh5IAWAAIAAB5gAJ3A9IAAh5IAdAAQAPAAAIAEQAIAEAEAJQADAIAAANIAAAsQAAAMgDAJQgEAJgIAFQgIAEgOAAgAKNAtIAHAAQAIAAADgDQAEgCAAgFIABgNIAAgtIgBgMQgBgFgDgCQgEgCgHAAIgHAAgAIyA9IgEgcIgWAAIgFAcIgVAAIAZh5IAXAAIAZB5gAIbATIAQAAIgIgzgAHNA9IAAgvIgZhKIAVAAIAPAwIAOgwIAUAAIgYBKIAAAvgAGbA9IgehIIAABIIgTAAIAAh5IAPAAIAeBFIAAhFIASAAIAAB5gAEbA9IAAh5IAkAAQAKAAAHAEQAHAEADAIQADAIAAALQAAAMgEAHQgEAGgHAEQgHADgKAAIgMAAIAAA2gAExgIIAIAAQAGAAAEgCQADgBABgEQACgEAAgGIgBgLQgCgEgCgCQgEgCgHAAIgIAAgAD6A9IgFgcIgVAAIgFAcIgVAAIAZh5IAXAAIAZB5gADiATIARAAIgJgzgACsA9IgUg4IgGAJIAAAvIgWAAIAAh5IAWAAIAAA2IAZg2IAVAAIgYA3IAaBCgAAHA9IgdhIIAABIIgSAAIAAh5IAPAAIAdBFIAAhFIASAAIAAB5gAhpA9IAAh5IAzAAIAAAQIgcAAIAAAjIAWAAIAAAOIgWAAIAAAoIAdAAIAAAQgAioA9IAAh5IAWAAIAABpIAeAAIAAAQgAlfA9IAAh5IAyAAIAAAPIgcAAIAAAkIAXAAIAAAOIgXAAIAAA4gAmAA9IgehIIAABIIgTAAIAAh5IAQAAIAdBFIAAhFIATAAIAAB5gAnaA9IAAh5IAWAAIAAB5gAofA9IgUg4IgFAJIAAAvIgWAAIAAh5IAWAAIAAA2IAYg2IAVAAIgXA3IAZBCgAp3A9IAAh5IAWAAIAAB5gAq3A9IAAh5IAWAAIAABpIAeAAIAAAQgArYA9IgUg4IgFAJIAAAvIgWAAIAAh5IAWAAIAAA2IAYg2IAVAAIgXA3IAaBCgAL1AxIAAgUIATAAIAAAUgAL1AAIAAgUIATAAIAAAUg");
	this.shape.setTransform(1.225,-0.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76.4,-6.5,155.3,12.4);


(lib.Tween11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CTAcopy();
	this.instance.setTransform(-82,-4,0.2064,0.2064);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82,-4,187.5,57.2);


(lib.Tween10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t2a();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t2b();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t2c();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t2d();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t1a();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t1b();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t1c();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t1d();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t1e();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.t1f();
	this.instance.setTransform(-240,-265.2,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-240,-265.2,480,530.4);


(lib.ghwai = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bolong();
	this.instance.setTransform(8,7,0.9352,0.9352);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFADA").s().p("AgGAjIAFgQIABgTIgBgPQgBgIgFgLIAGAAQAEAJACAIQADAKAAAHQAAAHgDAKQgCAJgEAJg");
	this.shape.setTransform(261.975,50.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFADA").s().p("AgJAXQgEgDgBgIIAJgBQAAAEACACQAAAAABABQAAAAABAAQAAABABAAQAAAAAAAAQADAAABgDQACgCAAgGQAAgFgCgCQgBgCgDABQgDAAgDACIgHgBIAFgbIAVAAIAAAKIgPAAIgBAJIAEgCQAGAAADAEQAFAFAAAIQAAAHgEAGQgEAGgHAAQgFAAgEgEg");
	this.shape_1.setTransform(259.275,50);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFADA").s().p("AgJAVQgFgGAAgPQAAgNAFgHQAEgGAGAAQAFAAADADQAEAEABAGIgIABQgBgGgEAAQgCAAgCADQgBACgBAKIADgDIAEgBQAFAAAEAEQAEAFAAAHQAAAIgEAFQgFAFgGAAQgFAAgEgGgAgDABQgBADAAAEQAAAGACACQAAABABAAQAAABAAAAQABAAAAABQAAAAABAAQAAAAABAAQABgBAAAAQAAAAABAAQAAgBABAAQABgCAAgGQAAgFgBgCQgBgCgEAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAABgBAAg");
	this.shape_2.setTransform(255.775,49.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFADA").s().p("AgJAXQgEgDgBgIIAJgBIACAGQAAAAABABQABAAAAAAQABABAAAAQAAAAAAAAQADAAABgDQACgCAAgGQAAgFgCgCQgBgCgDABQgDAAgDACIgHgBIAFgbIAVAAIAAAKIgPAAIgBAJIAFgCQAFAAADAEQAFAFAAAIQAAAHgEAGQgEAGgHAAQgFAAgEgEg");
	this.shape_3.setTransform(252.275,50);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFADA").s().p("AgJAVQgFgGAAgPQAAgNAFgHQAEgGAGAAQAFAAAEADQADAEABAGIgIABQgBgGgEAAQgBAAgDADQgCAEAAAIIAEgDIADgBQAFAAAEAEQAEAFAAAHQAAAIgEAFQgFAFgFAAQgGAAgEgGgAgDABQgBADAAAEQAAAGACACQAAABABAAQAAABABAAQAAAAAAABQAAAAABAAQAAAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQABgCAAgGQAAgFgBgCQgBgBAAAAQAAgBgBAAQAAAAgBAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAABgBAAg");
	this.shape_4.setTransform(248.775,49.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFADA").s().p("AgIAFIAAgJIAQAAIAAAJg");
	this.shape_5.setTransform(245.95,50.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFADA").s().p("AgHAaQAAgJADgNQAEgKAFgKIgSAAIAAgJIAbAAIAAAHIgHANQgEAHgBAIQgCAIAAAIg");
	this.shape_6.setTransform(243.125,49.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFADA").s().p("AgIAaQAAgJAEgNQADgKAGgKIgSAAIAAgJIAcAAIAAAHQgEAFgEAIIgGAPQgBAIAAAIg");
	this.shape_7.setTransform(239.65,49.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFADA").s().p("AABAbIAAgmQgDAGgGACIAAgJIAGgGQAEgDABgFIAHAAIAAA1g");
	this.shape_8.setTransform(235.9,49.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFADA").s().p("AgHAFIAAgJIAPAAIAAAJg");
	this.shape_9.setTransform(233.325,50.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFADA").s().p("AgJAVQgEgFAAgQQAAgPAEgFQAEgGAFAAQAHAAADAGQAEAGAAAOQAAAPgEAGQgDAGgHAAQgFAAgEgGgAgDgPQgCAEAAALQAAAMACADQABAEACAAQACAAACgEQABgDAAgMQAAgLgBgEQgCgDgCAAQgCAAgBADg");
	this.shape_10.setTransform(230.525,49.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFADA").s().p("AgJAVQgEgGAAgPQAAgOAEgGQAEgGAFAAQAHAAADAGQAEAGAAAOQAAAPgEAGQgDAGgHAAQgFAAgEgGgAgDgPQgBAEAAALQAAAMABADQABABAAABQAAAAABABQAAAAABABQAAAAAAAAQADAAABgEQABgDAAgMQAAgLgBgEQgBgDgDAAQAAAAAAAAQgBABAAAAQgBAAAAABQAAABgBAAg");
	this.shape_11.setTransform(227.025,49.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFADA").s().p("AgKAXQgDgFAAgHQAAgFACgDQABgDAEgCIgFgEQgCgDABgEQAAgGADgEQADgDAGAAQAHAAACAEQAEADAAAGQAAAEgBADIgFAEQAFACABADQABACAAAGQAAAFgBADQgCADgEADQgCACgFAAQgFAAgFgEgAgDAEQgCADAAADQAAAEACADQACACABAAQACAAADgCQABgCAAgFQAAgEgCgCQAAAAgBgBQAAAAgBgBQAAAAgBAAQAAAAgBAAQgCAAgBACgAgDgRIgBAFQAAABAAABQAAAAAAABQAAAAAAABQABAAAAABQAAAAABABQABAAAAAAQABAAAAABQAAAAAAAAIAEgCQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAgDgBgCQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAg");
	this.shape_12.setTransform(223.55,49.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFADA").s().p("AgJAVQgEgGAAgPQAAgOAEgGQAEgGAFAAQAHAAADAGQAEAFAAAPQAAAQgEAFQgDAGgHAAQgFAAgEgGgAgDgPQgBAEAAALQAAAMABADQACAEABAAQADAAABgEQACgDAAgMQAAgLgCgEQgBgDgDAAQgBAAgCADg");
	this.shape_13.setTransform(220.025,49.975);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFADA").s().p("AACAjQgEgJgCgIQgCgKgBgIQABgHACgKQACgIAEgJIAGAAIgGATIgCAPQAAAKACAJIAGAQg");
	this.shape_14.setTransform(217.3,50.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFADA").s().p("AAIAbIgLgZIgHAJIAAAQIgJAAIAAg1IAJAAIAAAYIARgYIAMAAIgRAVIASAgg");
	this.shape_15.setTransform(212.375,49.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFADA").s().p("AgOAVQgGgHAAgOQAAgIACgGQADgHAFgDQAEgDAGAAQAJAAAGAHQAGAIAAAMQAAAOgGAHQgGAHgJAAQgIAAgGgHgAgIgNQgDAEAAAJQAAAKADAEQAEAFAEAAQAFAAAEgFQADgEAAgKQAAgJgDgEQgDgEgGAAQgFAAgDAEg");
	this.shape_16.setTransform(207.475,49.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFADA").s().p("AAIAbIgKgZIgIAJIAAAQIgJAAIAAg1IAJAAIAAAYIARgYIAMAAIgRAVIASAgg");
	this.shape_17.setTransform(203,49.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFADA").s().p("AgOAVQgGgIgBgNQAAgIAEgGQADgHAEgDQAFgDAFAAQAKAAAFAHQAHAIAAAMQgBAOgGAHQgFAHgKAAQgJAAgFgHgAgHgNQgEAEAAAJQAAAKAEAEQADAFAEAAQAFAAAEgFQADgFAAgJQAAgJgDgEQgDgEgGAAQgEAAgDAEg");
	this.shape_18.setTransform(198.1,49.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFADA").s().p("AAJAbIgKgUQAAAAgBgBQAAAAAAAAQgBAAAAgBQAAAAgBAAIgEgBIgCAAIAAAXIgJAAIAAg1IATAAQAGAAADACQADABACAEQACADAAAFQAAAHgDADQgDAEgFAAIAEAFIAFAIIAGALgAgKgDIANgBQABAAAAAAQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAIgDgCIgNgBg");
	this.shape_19.setTransform(193.625,49.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFADA").s().p("AgQAbIAAg1IAgAAIAAAJIgXAAIAAAMIAVAAIAAAIIgVAAIAAAPIAYAAIAAAJg");
	this.shape_20.setTransform(189.125,49.925);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFADA").s().p("AANAbIAAgpIgJApIgHAAIgJgpIAAApIgIAAIAAg1IANAAIAHAkIAIgkIANAAIAAA1g");
	this.shape_21.setTransform(184.375,49.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFADA").s().p("AgDAbIAAg1IAHAAIAAA1g");
	this.shape_22.setTransform(179.125,49.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFADA").s().p("AgDAbIAAgsIgOAAIAAgJIAiAAIAAAJIgMAAIAAAsg");
	this.shape_23.setTransform(176.3,49.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFADA").s().p("AAJAbIgRgiIAAAiIgIAAIAAg1IAJAAIARAjIAAgjIAIAAIAAA1g");
	this.shape_24.setTransform(172.1,49.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFADA").s().p("AgQAbIAAg1IAgAAIAAAJIgXAAIAAAMIAVAAIAAAIIgVAAIAAAPIAYAAIAAAJg");
	this.shape_25.setTransform(167.875,49.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFADA").s().p("AAJAbIAAgYIgRAAIAAAYIgIAAIAAg1IAIAAIAAAVIARAAIAAgVIAJAAIAAA1g");
	this.shape_26.setTransform(163.45,49.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFADA").s().p("AAJAbIgKgUIgCgCIgFgBIgCAAIAAAXIgJAAIAAg1IATAAQAGAAADACQAEACABADQACADAAAFQAAAHgDADQgDAEgFAAIAFAFIAKATgAgKgDIAHAAIAHgBQAAAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBIABgEIgBgEIgDgCIgNgBg");
	this.shape_27.setTransform(159.125,49.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFADA").s().p("AgQAbIAAg1IAgAAIAAAJIgXAAIAAAMIAVAAIAAAIIgVAAIAAAPIAYAAIAAAJg");
	this.shape_28.setTransform(154.675,49.925);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFADA").s().p("AgRAbIAAg1IARAAQAGAAADACQADAAACAEQACADAAAFQAAAEgBADIgFAEQAEABACADQACADAAAFQAAAGgCAEQgEAFgDAAIgLABgAgJASIAPgBIACgCIABgEIgBgFIgDgCIgGgBIgIAAgAgJgEIAMgBIADgCQABAAAAgBQAAAAAAAAQABgBAAgBQAAAAAAgBIgBgEIgDgBIgHgBIgGAAg");
	this.shape_29.setTransform(150.325,49.925);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFADA").s().p("AAJAbIgRgiIAAAiIgJAAIAAg1IAJAAIARAjIAAgjIAJAAIAAA1g");
	this.shape_30.setTransform(143.95,49.925);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFADA").s().p("AAMAbIgDgMIgRAAIgEAMIgJAAIARg1IAIAAIASA1gAgGAGIAMAAIgGgTg");
	this.shape_31.setTransform(139.45,49.925);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFADA").s().p("AAIAbIgQgiIAAAiIgIAAIAAg1IAIAAIARAjIAAgjIAIAAIAAA1g");
	this.shape_32.setTransform(134.925,49.925);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFADA").s().p("AAMAbIgDgMIgRAAIgEAMIgJAAIARg1IAIAAIASA1gAgFAGIALAAIgGgTg");
	this.shape_33.setTransform(130.425,49.925);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFADA").s().p("AgEAbIAAgXIgQgeIALAAIAJAVIALgVIAJAAIgQAeIAAAXg");
	this.shape_34.setTransform(126.65,49.925);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFADA").s().p("AANAbIgFgMIgQAAIgEAMIgJAAIARg1IAIAAIASA1gAgFAGIALAAIgGgTg");
	this.shape_35.setTransform(122.85,49.925);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFADA").s().p("AgPAaIAAgzIAJAAIAAAqIAWAAIAAAJg");
	this.shape_36.setTransform(118.85,49.95);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFADA").s().p("AgEAGIAAgLIAJAAIAAALg");
	this.shape_37.setTransform(263.9,43.025);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFADA").s().p("AAOAfIgEgOIgTAAIgFAOIgKAAIATg9IAKAAIAVA9gAgGAGIAMAAIgGgVg");
	this.shape_38.setTransform(168.05,40.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFADA").s().p("AAKAfIgTgoIAAAoIgKAAIAAg9IAKAAIATApIAAgpIAKAAIAAA9g");
	this.shape_39.setTransform(162.85,40.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFADA").s().p("AgSAfIAAg9IAlAAIAAAKIgbAAIAAAPIAZAAIAAAJIgZAAIAAARIAbAAIAAAKg");
	this.shape_40.setTransform(157.925,40.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFADA").s().p("AAKAfIgNgdIgJALIAAASIgKAAIAAg9IAKAAIAAAbIAUgbIAOAAIgTAYIAUAlg");
	this.shape_41.setTransform(153.125,40.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFADA").s().p("AAKAfIgLgXIgDgCIgGgBIgCAAIAAAaIgKAAIAAg9IAWAAQAIAAACACQAEACACAEQACAEAAAFQAAAHgDAFQgEAEgGABIAGAFIAFAKIAHAMgAgMgEIAIAAIAIAAQAAAAABgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAgBAAgBQAAgDgBgBIgDgDIgIgBIgIAAg");
	this.shape_42.setTransform(147.925,40.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFADA").s().p("AgSAfIAAg9IAkAAIAAAKIgaAAIAAAPIAYAAIAAAJIgYAAIAAARIAbAAIAAAKg");
	this.shape_43.setTransform(142.775,40.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFADA").s().p("AgEAfIAAgzIgPAAIAAgKIAnAAIAAAKIgPAAIAAAzg");
	this.shape_44.setTransform(138.075,40.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFADA").s().p("AAPAfIgFgOIgTAAIgFAOIgLAAIAUg9IAKAAIAVA9gAgGAGIANAAIgHgVg");
	this.shape_45.setTransform(131.45,40.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFADA").s().p("AgEAfIAAgaIgTgjIAMAAIALAZIAMgZIAMAAIgTAjIAAAag");
	this.shape_46.setTransform(127.125,40.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFADA").s().p("AAOAfIgEgOIgUAAIgDAOIgLAAIAUg9IAJAAIAUA9gAgGAGIAMAAIgGgVg");
	this.shape_47.setTransform(122.75,40.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFADA").s().p("AgUALIAKgBQACALAIABQAEgBAEgCQACgCAAgEIgBgDIgCgDIgJgDIgJgEQgDgCgCgDQgCgEAAgEQAAgHADgCQACgEAEgDQAGgCADAAQAJAAAFAFQAEAEABAKIgKAAQgBgFgCgCQgCgCgEAAQgDABgDABQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAQABACAHADQAJACACACQAFADABADQACAEAAAFQAAAIgFAFQgGAGgKAAQgRAAgDgVg");
	this.shape_48.setTransform(117.725,40.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFADA").s().p("AAJAfIgSgnIAAAnIgKAAIAAg9IAKAAIATAoIAAgoIAKAAIAAA9g");
	this.shape_49.setTransform(260.5,40.525);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFADA").s().p("AAPAfIgFgOIgUAAIgDAOIgMAAIAVg9IAJAAIAVA9gAgGAGIANAAIgHgVg");
	this.shape_50.setTransform(255.3,40.525);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFADA").s().p("AAKAfIgNgdIgJAKIAAATIgKAAIAAg9IAKAAIAAAcIAUgcIAOAAIgTAYIAUAlg");
	this.shape_51.setTransform(250.375,40.525);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFADA").s().p("AgRAYQgHgHAAgRQAAgKAEgHQAEgIAEgCQAFgEAHAAQALAAAHAIQAGAJABAOQAAAPgIAJQgGAIgLAAQgJAAgIgIgAgJgPQgEAEAAALQAAALAEAFQAEAFAFAAQAGAAAEgFQAEgGAAgKQAAgKgEgFQgEgFgGAAQgFAAgEAFg");
	this.shape_52.setTransform(244.75,40.525);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFADA").s().p("AALAfIgMgXIgDgCIgFgBIgDAAIAAAaIgKAAIAAg9IAWAAQAHAAAEACQADABACAFQADAEAAAFQAAAIgEAEQgDADgHACIAGAFIAMAWgAgMgEIAIAAIAIAAQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAABgBQABgCAAgDQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAIgIAAIgIAAg");
	this.shape_53.setTransform(239.575,40.525);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFADA").s().p("AgRAYQgHgIAAgQQAAgKAEgHQADgHAGgDQAFgEAGAAQALAAAHAIQAHAIAAAPQgBAPgGAJQgHAIgLAAQgJAAgIgIgAgJgPQgEAFAAAKQAAAKAEAGQAEAFAFAAQAGAAAEgFQAEgGAAgKQAAgLgEgEQgEgFgGAAQgFAAgEAFg");
	this.shape_54.setTransform(233.95,40.525);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFADA").s().p("AgKAcQgGgDgDgIQgDgHAAgKQAAgKADgHQADgGAGgEQAFgEAGAAQAKAAAFAFQAGAFABAIIgKADQgBgGgDgCQgEgCgEAAQgFAAgEAFQgEAFAAAKQAAAKAEAGQAEAFAFAAIAHgBIAGgEIAAgIIgNAAIAAgJIAXAAIAAAXQgEAEgFADQgGADgHAAQgHAAgFgEg");
	this.shape_55.setTransform(228.3,40.525);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFADA").s().p("AgKAcQgGgEgDgHQgEgHAAgKQAAgKAEgHQADgGAFgEQAGgEAGAAQAKAAAFAFQAFAEACAJIgKADQgBgFgDgDQgEgCgEAAQgGAAgDAFQgEAFAAAKQAAAKAEAGQAEAFAFAAIAGgBIAGgEIAAgIIgLAAIAAgJIAWAAIAAAXQgFAFgFACQgFADgHAAQgHAAgFgEg");
	this.shape_56.setTransform(222.725,40.525);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFADA").s().p("AAKAfIgUgnIAAAnIgJAAIAAg9IAKAAIAUAoIAAgoIAJAAIAAA9g");
	this.shape_57.setTransform(217.35,40.525);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFADA").s().p("AgSAfIAAg9IAkAAIAAALIgaAAIAAANIAZAAIAAAKIgZAAIAAAQIAbAAIAAALg");
	this.shape_58.setTransform(212.45,40.525);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFADA").s().p("AgEAfIAAgyIgPAAIAAgLIAnAAIAAALIgPAAIAAAyg");
	this.shape_59.setTransform(207.75,40.525);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFADA").s().p("AALAfIgMgXIgDgCIgFgBIgCAAIAAAaIgLAAIAAg9IAWAAQAHAAAEACQAEABACAFQACADAAAGQAAAIgEAEQgCADgIACQAFACABADIAMAWgAgLgEIAHAAIAIAAIADgDIABgFIgBgEQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAIgHAAIgIAAg");
	this.shape_60.setTransform(201.125,40.525);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFADA").s().p("AgSAfIAAg9IAkAAIAAALIgaAAIAAANIAZAAIAAAKIgZAAIAAAQIAbAAIAAALg");
	this.shape_61.setTransform(195.975,40.525);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFADA").s().p("AAJAfIgMgdIgJAKIAAATIgKAAIAAg9IAKAAIAAAcIAUgcIAOAAIgTAYIAUAlg");
	this.shape_62.setTransform(191.175,40.525);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFADA").s().p("AAKAfIgTgnIAAAnIgKAAIAAg9IAKAAIAUAoIAAgoIAJAAIAAA9g");
	this.shape_63.setTransform(185.7,40.525);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFADA").s().p("AAPAfIgFgOIgTAAIgFAOIgLAAIAUg9IAKAAIAVA9gAgGAGIANAAIgHgVg");
	this.shape_64.setTransform(180.5,40.525);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFADA").s().p("AAKAfIgNgdIgJALIAAASIgKAAIAAg9IAKAAIAAAbIAUgbIAOAAIgTAYIAUAlg");
	this.shape_65.setTransform(175.575,40.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFADA").s().p("AgEAIQACgBACgCQAAgCAAgDIgEAAIAAgMIAJAAIAAAJQAAAHgCACQgBAEgEADg");
	this.shape_66.setTransform(225.025,34.225);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFADA").s().p("AAKAfIgOgdIgIAKIAAATIgKAAIAAg9IAKAAIAAAbIAUgbIAOAAIgTAYIAUAlg");
	this.shape_67.setTransform(221.7,31.05);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFADA").s().p("AgQAYQgIgIAAgPQAAgLAEgHQADgGAFgFQAFgDAHAAQALAAAHAJQAHAIAAAOQAAAQgIAIQgGAIgLAAQgKAAgGgIgAgJgPQgEAGAAAJQAAAKAEAGQAEAFAFAAQAGAAAEgFQAEgFAAgLQAAgLgEgEQgEgFgGgBQgFABgEAFg");
	this.shape_68.setTransform(216.075,31.05);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFADA").s().p("AAKAfIgNgdIgJAKIAAATIgKAAIAAg9IAKAAIAAAbIAUgbIAOAAIgTAYIAUAlg");
	this.shape_69.setTransform(210.925,31.05);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFADA").s().p("AgQAYQgIgIABgPQAAgKACgIQADgGAGgFQAFgDAHAAQAKAAAIAJQAGAIAAAOQABAQgIAIQgGAIgLAAQgKAAgGgIgAgKgPQgDAFAAAKQAAALAEAFQAEAFAFAAQAHAAADgFQAEgGAAgKQAAgKgEgFQgEgFgGgBQgFABgFAFg");
	this.shape_70.setTransform(205.3,31.05);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFADA").s().p("AALAfIgMgXIgDgDIgFAAIgDAAIAAAaIgKAAIAAg9IAWAAQAHAAAEABQAEADABAEQADAEAAAFQAAAHgEAFQgEAEgGABIAGAEIAMAXgAgMgEIAIAAIAIAAQAAgBABAAQAAAAABgBQAAAAAAAAQABgBAAAAQABgBAAgEQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAIgIgBIgIAAg");
	this.shape_71.setTransform(200.125,31.05);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFADA").s().p("AgSAfIAAg9IAkAAIAAAKIgaAAIAAAOIAYAAIAAAKIgYAAIAAARIAbAAIAAAKg");
	this.shape_72.setTransform(194.975,31.05);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFADA").s().p("AAPAfIAAgwIgKAwIgJAAIgKgwIAAAwIgKAAIAAg9IAQAAIAIApIAJgpIAQAAIAAA9g");
	this.shape_73.setTransform(189.5,31.05);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFADA").s().p("AAOAfIgEgOIgTAAIgFAOIgKAAIATg9IAKAAIAVA9gAgHAGIAOAAIgHgVg");
	this.shape_74.setTransform(182.1,31.05);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFADA").s().p("AAKAfIgTgoIAAAoIgKAAIAAg9IAKAAIATApIAAgpIAKAAIAAA9g");
	this.shape_75.setTransform(176.9,31.05);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFADA").s().p("AgSAfIAAg9IAlAAIAAAKIgbAAIAAAOIAZAAIAAAKIgZAAIAAARIAbAAIAAAKg");
	this.shape_76.setTransform(171.975,31.05);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFADA").s().p("AAKAfIgLgXQgBAAAAgBQAAAAgBgBQAAAAgBAAQAAAAgBgBIgFAAIgCAAIAAAaIgKAAIAAg9IAWAAQAHAAADABQAFADABAEQACADAAAGQAAAIgDAEQgDADgHACIAGAEIAMAXgAgMgEIAIAAIAIAAIADgDQABgBAAgEQAAgBAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAIgDgDIgIgBIgIAAg");
	this.shape_77.setTransform(167.175,31.05);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFADA").s().p("AAPAfIgFgOIgUAAIgDAOIgMAAIAVg9IAJAAIAVA9gAgGAGIANAAIgHgVg");
	this.shape_78.setTransform(161.7,31.05);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFADA").s().p("AAKAfIgNgdIgJAKIAAATIgKAAIAAg9IAKAAIAAAbIAUgbIAOAAIgTAYIAUAlg");
	this.shape_79.setTransform(156.775,31.05);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFADA").s().p("AgFAXIAAgMIALAAIAAAMgAgFgKIAAgMIALAAIAAAMg");
	this.shape_80.setTransform(215.975,21.975);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFADA").s().p("AAMAgIgYgpIAAApIgMAAIAAg/IAMAAIAZAqIAAgqIAMAAIAAA/g");
	this.shape_81.setTransform(211.225,21.075);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFADA").s().p("AASAgIgGgPIgYAAIgGAPIgNAAIAZg/IAMAAIAaA/gAgIAHIAQAAIgIgXg");
	this.shape_82.setTransform(204.775,21.075);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFADA").s().p("AgGAgIAAg0IgTAAIAAgLIAzAAIAAALIgTAAIAAA0g");
	this.shape_83.setTransform(199.5,21.075);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFADA").s().p("AASAgIgGgPIgYAAIgFAPIgOAAIAZg/IAMAAIAaA/gAgIAHIAQAAIgIgXg");
	this.shape_84.setTransform(194.175,21.075);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFADA").s().p("AgOAdQgHgEgEgIQgEgIAAgJQAAgJAFgIQADgIAIgEQAHgDAIAAQALAAAHAFQAIAFABAJIgMACQgCgFgDgCQgEgDgGAAQgHAAgGAFQgEAFAAALQAAALAEAFQAGAGAHAAQAFAAADgCIAHgDIAAgJIgPAAIAAgJIAcAAIAAAYQgEAEgHADQgIADgJAAQgJAAgHgEg");
	this.shape_85.setTransform(187.4,21.075);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFADA").s().p("AAMAgIgZgpIAAApIgMAAIAAg/IANAAIAZAqIAAgqIANAAIAAA/g");
	this.shape_86.setTransform(180.75,21.075);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFADA").s().p("AgFAgIAAg/IALAAIAAA/g");
	this.shape_87.setTransform(176.3,21.075);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFADA").s().p("AANAgIgPgXIgEgDIgJgBIAAAbIgNAAIAAg/IAbAAQAIAAAGACQAFABADAFQADAEAAAGQAAAHgFAFQgEADgIACIAHAFIAPAXgAgPgEIAUgBIAEgCQABgCAAgDQAAgEgCgBQgBgDgDAAIgJAAIgKAAg");
	this.shape_88.setTransform(172.125,21.075);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFADA").s().p("AgXAgIAAg/IAuAAIAAALIgiAAIAAAOIAgAAIAAAKIggAAIAAARIAjAAIAAALg");
	this.shape_89.setTransform(165.7,21.075);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFADA").s().p("AgXAgIAAg/IAUAAIAPABQAFABAEAFQAEAEgBAJQAAAGgBAEQgDACgDADQgCACgEABIgNABIgJAAIAAAYgAgLgCIAIAAQAHAAABgBQADgBACgCIABgFQAAgEgCgCQgBgCgEgBIgIAAIgHAAg");
	this.shape_90.setTransform(159.75,21.075);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFADA").s().p("AhxByQgwgvAAhDQAAhCAwgvQAvgwBCAAQBDAAAvAwQAwAvAABCQAABDgwAvQgvAwhDAAQhCAAgvgwgAhlhlQgrAqAAA7QAAA8ArAqQAqArA7AAQA8AAAqgrQArgqAAg8QAAg7grgqQgqgrg8AAQg7AAgqArg");
	this.shape_91.setTransform(293.825,35.975);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFADA").s().p("AgIAmIAAgcIgeAAIAAgTIAeAAIAAgcIASAAIAAAcIAdAAIAAATIgdAAIAAAcg");
	this.shape_92.setTransform(302.05,36.05);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFADA").s().p("AgXAwQgMgJAAgQQAAgJAEgIQAEgGAKgEQgIgDgEgHQgDgFAAgIQAAgMAIgIQAIgIAQAAQAQAAAIAIQAIAIAAAMQAAAIgDAGQgFAGgHADQAKAEAEAGQAFAHAAAJQAAAPgKAKQgKAJgQAAQgNAAgKgIgAgLAJQgDAFAAAHQAAAIAEAFQAFAFAFAAQAHAAAEgFQAEgEAAgJQAAgIgEgEQgFgFgGAAQgHAAgEAFgAgJgjQgEAEAAAGQAAAGAEADQADAEAGAAQAGAAADgEQAEgDAAgGQAAgHgEgDQgDgDgGAAQgGAAgDADg");
	this.shape_93.setTransform(293.275,36.075);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFADA").s().p("AADA3IAAhOQgLALgPAFIAAgTQAIgDAKgIQAIgHAEgKIARAAIAABtg");
	this.shape_94.setTransform(284.125,35.975);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#040202").s().p("A4/FoIAArPMAx/AAAIAALPg");
	this.shape_95.setTransform(160,36);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,320,72);


(lib.bm_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_23
	this.instance = new lib.BukanMain03();
	this.instance.setTransform(0,0,1.3333,1.3333);

	this.instance_1 = new lib.BukanMain04();
	this.instance_1.setTransform(0,0,1.3333,1.3333);

	this.instance_2 = new lib.BukanMain05();
	this.instance_2.setTransform(0,0,1.3333,1.3333);

	this.instance_3 = new lib.BukanMain07();
	this.instance_3.setTransform(0,0,1.3333,1.3333);

	this.instance_4 = new lib.BukanMain08();
	this.instance_4.setTransform(0,0,1.3333,1.3333);

	this.instance_5 = new lib.BukanMain09();
	this.instance_5.setTransform(0,0,1.3333,1.3333);

	this.instance_6 = new lib.BukanMain11();
	this.instance_6.setTransform(0,0,1.3333,1.3333);

	this.instance_7 = new lib.BukanMain13();
	this.instance_7.setTransform(0,0,1.3333,1.3333);

	this.instance_8 = new lib.bm();
	this.instance_8.setTransform(0,0,0.64,0.64);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},95).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).wait(97));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,320,480);


(lib.tangan2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// tangan2
	this.instance = new lib.Tween29("synched",0);
	this.instance.setTransform(162.95,234.2,0.0566,1,0,0,0,-76.9,-31);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({regX:-77,scaleX:0.1221,x:163.95},3).to({regX:-76.2,scaleX:1.2673,x:164.45},5).to({scaleX:1.0012,x:164.1},2).wait(20).to({startPosition:0},0).to({regX:-75.7,scaleX:0.0244,x:164.05},2).to({regX:-73.9,scaleX:0.9999,scaleY:0.9888,skewY:180,x:147.55,y:234.5},2).wait(22).to({startPosition:0},0).to({regX:-74.9,scaleX:0.024,x:147.5},2).to({regX:-76.9,scaleX:0.9999,scaleY:1.0021,skewY:0,x:165.1,y:235.2},2).wait(19).to({regX:-76.2,scaleX:1.0012,scaleY:1,x:164.1,y:234.2},0).to({regX:-75.7,scaleX:0.0244,x:164.05},2).to({regX:-73.9,scaleX:0.9999,scaleY:0.9888,skewY:180,x:147.55,y:234.5},2).wait(23).to({startPosition:0},0).to({regX:-74.9,scaleX:0.024,x:147.5},2).to({regX:-76.9,scaleX:0.9999,scaleY:1.0021,skewY:0,x:165.1,y:235.2},2).wait(31));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-166.3,-82.8,731.5,773.6999999999999);


(lib.tangan1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// tangan
	this.instance = new lib.Tween13("synched",0);
	this.instance.setTransform(204.5,103.2,0.0395,1,0,0,180,-74.6,-162);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({_off:false},0).to({regX:-74,scaleX:0.3983,x:205.15,alpha:1},3).to({scaleX:1.2068,x:203.05},3,cjs.Ease.sineOut).to({scaleX:1.003,x:203},2).wait(23).to({startPosition:0},0).to({regX:-74.4,scaleX:0.0128,x:203.05},2).to({skewY:0,x:205.05},1).to({regX:-67.3,scaleX:0.9969,x:173.6},2).wait(19).to({startPosition:0},0).to({regX:-67.1,scaleX:0.0551,x:173.5},2).to({regX:-66.7,scaleX:0.0307,skewY:180,x:173.45},1).to({regX:-66.9,scaleX:1.0439,x:196.6},2).wait(20).to({regX:-74,scaleX:1.003,x:203},0).to({regX:-74.4,scaleX:0.0128,x:203.05},2).to({skewY:0,x:205.05},1).to({regX:-67.3,scaleX:0.9969,x:173.6},2).wait(20).to({startPosition:0},0).to({regX:-67.1,scaleX:0.0551,x:173.5},2).to({regX:-66.7,scaleX:0.0307,skewY:180,x:173.45},1).to({regX:-66.9,scaleX:1.0439,x:196.6},2).wait(21).to({regX:-74,scaleX:1.003,x:203},0).to({regX:-74.4,scaleX:0.0128,x:203.05},2).to({skewY:0,x:205.05},1).to({regX:-67.3,scaleX:0.9969,x:173.6},2).wait(38));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-175.9,0,655.8,530.5);


(lib.T6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// t6d_png
	this.instance = new lib.Tween30("synched",0);
	this.instance.setTransform(275,315.2,1,1,0,0,0,68,-28);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(54).to({_off:false},0).to({y:232.2,alpha:1},4,cjs.Ease.quintOut).to({y:237.2},2).wait(4).to({startPosition:0},0).to({x:308},3).wait(28).to({y:238.2},0).to({y:236.2},1).to({x:307,y:237.2},1).to({y:236.2},1).to({x:309},1).to({x:307,y:238.2},1).to({x:308,y:237.2},1).to({x:307},1).to({x:309,y:236.2},1).to({x:308,y:238.2},1).to({x:307,y:237.2},1).to({x:309},1).to({x:307},1).to({x:308,y:238.2},1).to({y:236.2},1).to({x:307,y:237.2},1).to({x:308,y:238.2},1).to({y:236.2},1).to({x:307,y:237.2},1).to({x:308},1).wait(30).to({y:238.2},0).to({y:236.2},1).to({x:307,y:237.2},1).to({y:236.2},1).to({x:309},1).to({x:307,y:238.2},1).to({x:308,y:237.2},1).to({x:307},1).to({x:309,y:236.2},1).to({x:308,y:238.2},1).to({x:307,y:237.2},1).to({x:309},1).to({x:307},1).to({x:308,y:238.2},1).to({y:236.2},1).to({x:307,y:237.2},1).to({x:308,y:238.2},1).to({y:236.2},1).to({x:307,y:237.2},1).to({x:308},1).wait(1).to({startPosition:0},0).wait(36));

	// t6c_png
	this.instance_1 = new lib.Tween31("synched",0);
	this.instance_1.setTransform(243.1,319.2,1,1,0,0,0,36.1,-24);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(54).to({_off:false},0).to({y:236.2,alpha:1},4,cjs.Ease.quintOut).to({y:241.2},2).wait(4).to({startPosition:0},0).to({x:276.1},3).wait(28).to({x:277.1},0).to({x:275.1},1).to({x:276.1,y:240.2},1).to({x:277.1},1).to({x:275.1,y:242.2},1).to({x:276.1},1).to({y:240.2},1).to({x:277.1,y:241.2},1).to({x:275.1},1).to({x:277.1,y:242.2},1).to({x:275.1,y:240.2},1).to({x:277.1,y:241.2},1).to({x:275.1},1).to({x:276.1,y:240.2},1).to({y:242.2},1).to({x:277.1,y:241.2},1).to({x:275.1},1).to({x:276.1,y:240.2},1).to({y:242.2},1).to({y:241.2},1).wait(30).to({x:277.1},0).to({x:275.1},1).to({x:276.1,y:240.2},1).to({x:277.1},1).to({x:275.1,y:242.2},1).to({x:276.1},1).to({y:240.2},1).to({x:277.1,y:241.2},1).to({x:275.1},1).to({x:277.1,y:242.2},1).to({x:275.1,y:240.2},1).to({x:277.1,y:241.2},1).to({x:275.1},1).to({x:276.1,y:240.2},1).to({y:242.2},1).to({x:277.1,y:241.2},1).to({x:275.1},1).to({x:276.1,y:240.2},1).to({y:242.2},1).to({y:241.2},1).wait(1).to({startPosition:0},0).wait(36));

	// t6b_png
	this.instance_2 = new lib.Tween32("synched",0);
	this.instance_2.setTransform(211,318.2,1,1,0,0,0,4,-25);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(54).to({_off:false},0).to({y:235.2,alpha:1},4,cjs.Ease.quintOut).to({y:240.2},2).wait(4).to({startPosition:0},0).to({x:244},3).wait(28).to({y:239.2},0).to({y:241.2},1).to({x:245,y:240.2},1).to({x:243},1).to({x:245,y:239.2},1).to({x:243,y:241.2},1).to({x:244},1).to({x:245,y:240.2},1).to({x:243},1).to({x:244,y:239.2},1).to({x:243,y:240.2},1).to({x:245},1).to({y:241.2},1).to({x:243,y:239.2},1).to({x:245,y:240.2},1).to({x:243},1).to({x:244,y:239.2},1).to({x:245},1).to({x:243,y:240.2},1).to({x:244},1).wait(30).to({y:239.2},0).to({y:241.2},1).to({x:245,y:240.2},1).to({x:243},1).to({x:245,y:239.2},1).to({x:243,y:241.2},1).to({x:244},1).to({x:245,y:240.2},1).to({x:243},1).to({x:244,y:239.2},1).to({x:243,y:240.2},1).to({x:245},1).to({y:241.2},1).to({x:243,y:239.2},1).to({x:245,y:240.2},1).to({x:243},1).to({x:244,y:239.2},1).to({x:245},1).to({x:243,y:240.2},1).to({x:244},1).wait(1).to({startPosition:0},0).wait(36));

	// t6a_png
	this.instance_3 = new lib.Tween33("synched",0);
	this.instance_3.setTransform(183.9,311.2,1,1,0,0,0,-23.1,-32);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(54).to({_off:false},0).to({y:228.2,alpha:1},4,cjs.Ease.quintOut).to({y:233.2},2).wait(4).to({startPosition:0},0).to({x:216.9},3).wait(28).to({x:217.9,y:232.2},0).to({x:215.9,y:233.2},1).to({x:217.9},1).to({x:216.9,y:234.2},1).to({y:232.2},1).to({x:215.9,y:233.2},1).to({x:217.9},1).to({x:215.9,y:234.2},1).to({x:217.9,y:232.2},1).to({x:215.9,y:233.2},1).to({x:217.9},1).to({x:216.9,y:234.2},1).to({x:217.9,y:233.2},1).to({x:215.9},1).to({x:216.9},1).to({y:234.2},1).to({x:217.9,y:233.2},1).to({x:215.9},1).to({x:216.9,y:232.2},1).to({y:233.2},1).wait(30).to({x:217.9,y:232.2},0).to({x:215.9,y:233.2},1).to({x:217.9},1).to({x:216.9,y:234.2},1).to({y:232.2},1).to({x:215.9,y:233.2},1).to({x:217.9},1).to({x:215.9,y:234.2},1).to({x:217.9,y:232.2},1).to({x:215.9,y:233.2},1).to({x:217.9},1).to({x:216.9,y:234.2},1).to({x:217.9,y:233.2},1).to({x:215.9},1).to({x:216.9},1).to({y:234.2},1).to({x:217.9,y:233.2},1).to({x:215.9},1).to({x:216.9,y:232.2},1).to({y:233.2},1).wait(1).to({startPosition:0},0).wait(36));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33,-5,514,613.4);


(lib.T5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// t5d_png
	this.instance = new lib.Tween25("synched",0);
	this.instance.setTransform(151.9,43.15,1,1,0,0,0,-130.1,-30);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(54).to({_off:false},0).to({y:241.2,alpha:1},4,cjs.Ease.quintOut).to({y:235.2},2).wait(4).to({startPosition:0},0).to({x:109.9},3,cjs.Ease.sineOut).wait(5).to({x:110.9},0).to({x:108.9},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:108.9},1).to({x:110.9,y:234.2},1).to({x:108.9,y:236.2},1).to({x:110.9,y:235.2},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:108.9,y:235.2},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:111.9,y:234.2},1).to({x:108.9,y:235.2},1).to({x:109.9,y:236.2},1).to({y:235.2},1).wait(33).to({x:110.9},0).to({x:108.9},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:108.9},1).to({x:110.9,y:234.2},1).to({x:108.9,y:236.2},1).to({x:110.9,y:235.2},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:108.9,y:235.2},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:111.9,y:234.2},1).to({x:108.9,y:235.2},1).to({x:109.9,y:236.2},1).to({y:235.2},1).wait(1).to({startPosition:0},0).wait(32).to({x:110.9},0).to({x:108.9},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:108.9},1).to({x:110.9,y:234.2},1).to({x:108.9,y:236.2},1).to({x:110.9,y:235.2},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:108.9,y:235.2},1).to({x:109.9,y:234.2},1).to({y:236.2},1).to({x:111.9,y:234.2},1).to({x:108.9,y:235.2},1).to({x:109.9,y:236.2},1).to({y:235.2},1).wait(1).to({startPosition:0},0).wait(13));

	// t5c_png
	this.instance_1 = new lib.Tween26("synched",0);
	this.instance_1.setTransform(125.9,44.15,1,1,0,0,0,-156.1,-29);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(54).to({_off:false},0).to({y:242.2,alpha:1},4,cjs.Ease.quintOut).to({y:236.2},2).wait(4).to({startPosition:0},0).to({x:83.9},3,cjs.Ease.sineOut).wait(5).to({y:234.2},0).to({x:84.9,y:236.2},1).to({x:82.9},1).to({x:84.9,y:237.2},1).to({x:82.9},1).to({x:83.9,y:235.2},1).to({x:85.9,y:236.2},1).to({x:82.9},1).to({x:83.9,y:235.2},1).to({x:82.9,y:236.2},1).to({y:237.2},1).to({x:84.9,y:236.2},1).to({y:235.2},1).to({x:82.9,y:237.2},1).to({x:83.9},1).to({x:82.9,y:236.2},1).to({x:83.9},1).wait(33).to({y:234.2},0).to({x:84.9,y:236.2},1).to({x:82.9},1).to({x:84.9,y:237.2},1).to({x:82.9},1).to({x:83.9,y:235.2},1).to({x:85.9,y:236.2},1).to({x:82.9},1).to({x:83.9,y:235.2},1).to({x:82.9,y:236.2},1).to({y:237.2},1).to({x:84.9,y:236.2},1).to({y:235.2},1).to({x:82.9,y:237.2},1).to({x:83.9},1).to({x:82.9,y:236.2},1).to({x:83.9},1).wait(1).to({startPosition:0},0).wait(32).to({y:234.2},0).to({x:84.9,y:236.2},1).to({x:82.9},1).to({x:84.9,y:237.2},1).to({x:82.9},1).to({x:83.9,y:235.2},1).to({x:85.9,y:236.2},1).to({x:82.9},1).to({x:83.9,y:235.2},1).to({x:82.9,y:236.2},1).to({y:237.2},1).to({x:84.9,y:236.2},1).to({y:235.2},1).to({x:82.9,y:237.2},1).to({x:83.9},1).to({x:82.9,y:236.2},1).to({x:83.9},1).wait(1).to({startPosition:0},0).wait(13));

	// t5b_png
	this.instance_2 = new lib.Tween27("synched",0);
	this.instance_2.setTransform(97.9,38.15,1,1,0,0,0,-184.1,-35);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(54).to({_off:false},0).to({y:236.2,alpha:1},4,cjs.Ease.quintOut).to({y:230.2},2).wait(4).to({startPosition:0},0).to({x:55.9},3,cjs.Ease.sineOut).wait(5).to({x:54.9,y:231.2},0).to({x:56.9,y:230.2},1).to({x:55.9,y:229.2},1).to({x:54.9,y:231.2},1).to({x:55.9,y:229.2},1).to({y:231.2},1).to({x:56.9,y:230.2},1).to({x:54.9},1).to({x:56.9,y:231.2},1).to({x:54.9,y:229.2},1).to({x:55.9,y:231.2},1).to({y:229.2},1).to({x:54.9,y:230.2},1).to({x:56.9},1).to({y:231.2},1).to({x:54.9},1).to({x:55.9,y:230.2},1).wait(33).to({x:54.9,y:231.2},0).to({x:56.9,y:230.2},1).to({x:55.9,y:229.2},1).to({x:54.9,y:231.2},1).to({x:55.9,y:229.2},1).to({y:231.2},1).to({x:56.9,y:230.2},1).to({x:54.9},1).to({x:56.9,y:231.2},1).to({x:54.9,y:229.2},1).to({x:55.9,y:231.2},1).to({y:229.2},1).to({x:54.9,y:230.2},1).to({x:56.9},1).to({y:231.2},1).to({x:54.9},1).to({x:55.9,y:230.2},1).wait(1).to({startPosition:0},0).wait(32).to({x:54.9,y:231.2},0).to({x:56.9,y:230.2},1).to({x:55.9,y:229.2},1).to({x:54.9,y:231.2},1).to({x:55.9,y:229.2},1).to({y:231.2},1).to({x:56.9,y:230.2},1).to({x:54.9},1).to({x:56.9,y:231.2},1).to({x:54.9,y:229.2},1).to({x:55.9,y:231.2},1).to({y:229.2},1).to({x:54.9,y:230.2},1).to({x:56.9},1).to({y:231.2},1).to({x:54.9},1).to({x:55.9,y:230.2},1).wait(1).to({startPosition:0},0).wait(13));

	// t5a_png
	this.instance_3 = new lib.Tween28("synched",0);
	this.instance_3.setTransform(69.9,41.15,1,1,0,0,0,-212.1,-32);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(54).to({_off:false},0).to({y:239.2,alpha:1},4,cjs.Ease.quintOut).to({y:233.2},2).wait(4).to({startPosition:0},0).to({x:27.9},3,cjs.Ease.sineOut).wait(5).to({y:232.2},0).to({x:28.9,y:233.2},1).to({x:26.9,y:234.2},1).to({x:27.9,y:232.2},1).to({x:28.9,y:233.2},1).to({x:26.9},1).to({y:234.2},1).to({x:28.9,y:232.2},1).to({y:233.2},1).to({x:26.9,y:234.2},1).to({x:28.9,y:233.2},1).to({x:26.9},1).to({x:27.9,y:232.2},1).to({y:234.2},1).to({x:26.9,y:233.2},1).to({x:28.9},1).to({x:27.9},1).wait(33).to({y:232.2},0).to({x:28.9,y:233.2},1).to({x:26.9,y:234.2},1).to({x:27.9,y:232.2},1).to({x:28.9,y:233.2},1).to({x:26.9},1).to({y:234.2},1).to({x:28.9,y:232.2},1).to({y:233.2},1).to({x:26.9,y:234.2},1).to({x:28.9,y:233.2},1).to({x:26.9},1).to({x:27.9,y:232.2},1).to({y:234.2},1).to({x:26.9,y:233.2},1).to({x:28.9},1).to({x:27.9},1).wait(1).to({startPosition:0},0).wait(32).to({y:232.2},0).to({x:28.9,y:233.2},1).to({x:26.9,y:234.2},1).to({x:27.9,y:232.2},1).to({x:28.9,y:233.2},1).to({x:26.9},1).to({y:234.2},1).to({x:28.9,y:232.2},1).to({y:233.2},1).to({x:26.9,y:234.2},1).to({x:28.9,y:233.2},1).to({x:26.9},1).to({x:27.9,y:232.2},1).to({y:234.2},1).to({x:26.9,y:233.2},1).to({x:28.9},1).to({x:27.9},1).wait(1).to({startPosition:0},0).wait(13));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-192,523,728.4);


(lib.T4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// t4c_png
	this.instance = new lib.Tween22("synched",0);
	this.instance.setTransform(346.75,171.4,2.213,2.213,0,0,0,0,-95);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(40).to({_off:false},0).to({regX:0.1,scaleX:0.9556,scaleY:0.9556,x:236.2,y:170.15},6).to({scaleX:1.0277,scaleY:1.0277,x:242.5,y:170.2},2).to({scaleX:0.9778,scaleY:0.9778,x:238.15,y:170.15},2).to({regX:0,scaleX:1,scaleY:1,x:240,y:170.2},1).to({x:252},4).to({startPosition:0},2).to({x:240},2).wait(141));

	// t4b_png
	this.instance_1 = new lib.Tween23("synched",0);
	this.instance_1.setTransform(152.05,169.25,2.213,2.213,180,0,0,-88,-96);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(40).to({_off:false},0).to({scaleX:0.9556,scaleY:0.9556,y:169.2},6).to({scaleX:1.0277,scaleY:1.0277,x:152},2).to({scaleX:0.9778,scaleY:0.9778,y:169.15},2).to({scaleX:1,scaleY:1,y:169.2},1).to({regX:-88.1,rotation:269.1764,x:151.9,y:169.3},4).to({regX:-88,regY:-95.9,rotation:359.8592,x:152.15,y:169.35},2).wait(143));

	// t4a_png
	this.instance_2 = new lib.Tween24("synched",0);
	this.instance_2.setTransform(-13.95,167,2.213,2.213,0,0,0,-163,-97);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(40).to({_off:false},0).to({scaleX:0.9556,scaleY:0.9556,x:80.35,y:168.25},6).to({scaleX:1.0277,scaleY:1.0277,x:74.9,y:168.15},2).to({scaleX:0.9778,scaleY:0.9778,x:78.65,y:168.2},2).to({scaleX:1,scaleY:1,x:77},1).to({x:62},4).to({startPosition:0},2).to({x:77},2).wait(141));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-573.8,-630.1,1451.6999999999998,1598.7);


(lib.T3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// t3d_png
	this.instance = new lib.Tween19("synched",0);
	this.instance.setTransform(291,-0.1,1,1,0,0,0,77,-161);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({y:110.2,alpha:1},4,cjs.Ease.sineOut).to({y:104.2},2).wait(5).to({startPosition:0},0).to({x:317},3).wait(28).to({x:318,y:103.2},0).to({x:316,y:104.2},1).to({x:318},1).to({x:317,y:103.2},1).to({y:105.2},1).to({x:318,y:104.2},1).to({x:317,y:105.2},1).to({x:316},1).to({x:318,y:103.2},1).to({x:316,y:105.2},1).to({x:318,y:104.2},1).to({x:317,y:103.2},1).to({x:315,y:104.2},1).to({x:317,y:102.2},1).to({y:106.2},1).to({x:319,y:104.2},1).to({x:317},1).to({startPosition:0},1).wait(33).to({x:318,y:103.2},0).to({x:316,y:104.2},1).to({x:318},1).to({x:317,y:103.2},1).to({y:105.2},1).to({x:318,y:104.2},1).to({x:317,y:105.2},1).to({x:316},1).to({x:318,y:103.2},1).to({x:316,y:105.2},1).to({x:318,y:104.2},1).to({x:317,y:103.2},1).to({x:315,y:104.2},1).to({x:317,y:102.2},1).to({y:106.2},1).to({x:319,y:104.2},1).to({x:317},1).to({startPosition:0},1).wait(1).to({startPosition:0},0).wait(70));

	// t3c_png
	this.instance_1 = new lib.Tween20("synched",0);
	this.instance_1.setTransform(266,4.9,1,1,0,0,0,52,-156);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({y:115.2,alpha:1},4,cjs.Ease.sineOut).to({y:109.2},2).wait(5).to({startPosition:0},0).to({x:292},3).wait(28).to({x:291},0).to({x:292,y:111.2},1).to({x:293,y:108.2},1).to({x:291},1).to({x:293,y:109.2},1).to({x:291},1).to({x:292,y:108.2},1).to({y:110.2},1).to({x:291,y:109.2},1).to({x:293},1).to({y:108.2},1).to({x:291,y:110.2},1).to({x:293,y:109.2},1).to({x:291},1).to({y:110.2},1).to({x:293,y:109.2},1).to({x:292,y:108.2},1).to({y:109.2},1).wait(33).to({x:291},0).to({x:292,y:111.2},1).to({x:293,y:108.2},1).to({x:291},1).to({x:293,y:109.2},1).to({x:291},1).to({x:292,y:108.2},1).to({y:110.2},1).to({x:291,y:109.2},1).to({x:293},1).to({y:108.2},1).to({x:291,y:110.2},1).to({x:293,y:109.2},1).to({x:291},1).to({y:110.2},1).to({x:293,y:109.2},1).to({x:292,y:108.2},1).to({y:109.2},1).wait(1).to({startPosition:0},0).wait(70));

	// t3b_png
	this.instance_2 = new lib.Tween21("synched",0);
	this.instance_2.setTransform(240,3.9,1,1,0,0,0,26,-157);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(20).to({_off:false},0).to({y:114.2,alpha:1},4,cjs.Ease.sineOut).to({y:108.2},2).wait(5).to({startPosition:0},0).to({x:266},3).wait(28).to({y:107.2},0).to({y:109.2},1).to({x:265,y:108.2},1).to({x:267},1).to({y:107.2},1).to({x:265,y:109.2},1).to({x:266,y:108.2},1).to({x:267,y:109.2},1).to({x:265,y:107.2},1).to({x:267,y:108.2},1).to({y:107.2},1).to({x:265,y:108.2},1).to({x:266,y:107.2},1).to({x:265,y:109.2},1).to({x:266},1).to({x:267,y:108.2},1).to({x:265,y:107.2},1).to({x:266,y:108.2},1).wait(33).to({y:107.2},0).to({y:109.2},1).to({x:265,y:108.2},1).to({x:267},1).to({y:107.2},1).to({x:265,y:109.2},1).to({x:266,y:108.2},1).to({x:267,y:109.2},1).to({x:265,y:107.2},1).to({x:267,y:108.2},1).to({y:107.2},1).to({x:265,y:108.2},1).to({x:266,y:107.2},1).to({x:265,y:109.2},1).to({x:266},1).to({x:267,y:108.2},1).to({x:265,y:107.2},1).to({x:266,y:108.2},1).wait(1).to({startPosition:0},0).wait(70));

	// t3a_png
	this.instance_3 = new lib.Tween18("synched",0);
	this.instance_3.setTransform(215,4.9,1,1,0,0,0,1,-156);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(20).to({_off:false},0).to({y:115.2,alpha:1},4,cjs.Ease.sineOut).to({y:109.2},2).wait(5).to({startPosition:0},0).to({x:241},3).wait(28).to({x:240},0).to({x:241,y:108.2},1).to({x:242,y:110.2},1).to({x:240},1).to({x:242,y:109.2},1).to({x:240},1).to({x:241,y:110.2},1).to({x:242,y:108.2},1).to({x:240,y:110.2},1).to({x:241,y:108.2},1).to({x:240},1).to({x:242,y:109.2},1).to({x:240,y:110.2},1).to({y:108.2},1).to({x:242,y:109.2},1).to({x:240},1).to({x:241,y:108.2},1).to({y:109.2},1).wait(33).to({x:240},0).to({x:241,y:108.2},1).to({x:242,y:110.2},1).to({x:240},1).to({x:242,y:109.2},1).to({x:240},1).to({x:241,y:110.2},1).to({x:242,y:108.2},1).to({x:240,y:110.2},1).to({x:241,y:108.2},1).to({x:240},1).to({x:242,y:109.2},1).to({x:240,y:110.2},1).to({y:108.2},1).to({x:242,y:109.2},1).to({x:240},1).to({x:241,y:108.2},1).to({y:109.2},1).wait(1).to({startPosition:0},0).wait(70));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-104.3,508,640.6999999999999);


(lib.T2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// t2d_png
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(168,204.2,1,1,0,0,0,-112,-153);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({y:108.2,alpha:1},4,cjs.Ease.sineOut).to({y:112.2},2).wait(5).to({startPosition:0},0).to({x:128},3).wait(5).to({y:113.2},0).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({x:130,y:112.2},1).to({x:128},1).to({y:113.2},1).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({y:113.2},1).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({y:112},1).wait(32).to({y:113.2},0).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({x:130,y:112.2},1).to({x:128},1).to({y:113.2},1).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({y:113.2},1).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({y:112},1).wait(1).to({startPosition:0},0).wait(32).to({y:113.2},0).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({x:130,y:112.2},1).to({x:128},1).to({y:113.2},1).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({y:113.2},1).to({x:126,y:112.2},1).to({x:129,y:113.2},1).to({x:127},1).to({x:128,y:110.2},1).to({y:112},1).wait(1).to({startPosition:0},0).wait(44));

	// t2c_png
	this.instance_1 = new lib.Tween8("synched",0);
	this.instance_1.setTransform(136,203.2,1,1,0,0,0,-144,-154);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({y:107.2,alpha:1},4,cjs.Ease.sineOut).to({y:111.2},2).wait(5).to({startPosition:0},0).to({x:96},3).wait(5).to({y:109.2},0).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:98},1).to({x:96},1).to({y:109.2},1).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:96,y:109.2},1).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:96,y:111},1).wait(32).to({y:109.2},0).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:98},1).to({x:96},1).to({y:109.2},1).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:96,y:109.2},1).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:96,y:111},1).wait(1).to({startPosition:0},0).wait(32).to({y:109.2},0).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:98},1).to({x:96},1).to({y:109.2},1).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:96,y:109.2},1).to({x:94,y:111.2},1).to({x:98,y:109.2},1).to({x:96,y:113.2},1).to({x:94,y:111.2},1).to({x:96,y:111},1).wait(1).to({startPosition:0},0).wait(44));

	// t2b_png
	this.instance_2 = new lib.Tween9("synched",0);
	this.instance_2.setTransform(100,200.2,1,1,0,0,0,-180,-157);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(20).to({_off:false},0).to({y:104.2,alpha:1},4,cjs.Ease.sineOut).to({y:108.2},2).wait(5).to({startPosition:0},0).to({x:60},3).wait(5).to({x:62},0).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({x:60,y:106.2},1).to({y:108.2},1).to({x:62},1).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({startPosition:0},1).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({x:60,y:108},1).wait(32).to({x:62,y:108.2},0).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({x:60,y:106.2},1).to({y:108.2},1).to({x:62},1).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({startPosition:0},1).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({x:60,y:108},1).wait(1).to({startPosition:0},0).wait(32).to({x:62,y:108.2},0).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({x:60,y:106.2},1).to({y:108.2},1).to({x:62},1).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({startPosition:0},1).to({x:60,y:106.2},1).to({y:110.2},1).to({x:58,y:108.2},1).to({x:62},1).to({x:60,y:108},1).wait(1).to({startPosition:0},0).wait(44));

	// t2a_png
	this.instance_3 = new lib.Tween10("synched",0);
	this.instance_3.setTransform(67,205.2,1,1,0,0,0,-213,-152);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(20).to({_off:false},0).to({y:109.2,alpha:1},4,cjs.Ease.sineOut).to({y:113.2},2).wait(5).to({startPosition:0},0).to({x:27},3).wait(5).to({x:28,y:112.2},0).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({x:25},1).to({x:27},1).to({x:28,y:112.2},1).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({y:112.2},1).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({x:27,y:113},1).wait(32).to({x:28,y:112.2},0).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({x:25},1).to({x:27},1).to({x:28,y:112.2},1).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({y:112.2},1).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({x:27,y:113},1).wait(1).to({startPosition:0},0).wait(32).to({x:28,y:112.2},0).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({x:25},1).to({x:27},1).to({x:28,y:112.2},1).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({y:112.2},1).to({x:26},1).to({x:27,y:115.2},1).to({y:111.2},1).to({x:28,y:113.2},1).to({x:27,y:113},1).wait(1).to({startPosition:0},0).wait(44));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2,-4,522,626.4);


(lib.T1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// t1f_png
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(194.95,43.2,0.4444,0.4444,0,0,0,-45,-222);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({regX:-44.9,regY:-221.8,scaleX:1.21,scaleY:1.21,y:43.3},6,cjs.Ease.sineOut).to({regX:-45,regY:-222,scaleX:1,scaleY:1,x:195,y:43.2},4).wait(177));

	// t1e_png
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(163,42.2,0.4313,0.4313,0,0,0,-77,-223);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).to({regX:-76.8,regY:-222.9,scaleX:1.1985,scaleY:1.1985,x:163.1,y:42.15},6,cjs.Ease.sineOut).to({regX:-77,regY:-223,scaleX:1,scaleY:1,x:163,y:42.2},4).wait(179));

	// t1d_png
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(128,41.2,0.4175,0.4175,0,0,0,-112,-224);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(9).to({_off:false},0).to({regY:-223.8,scaleX:1.2672,scaleY:1.2672,x:127.85,y:41.3},6,cjs.Ease.sineOut).to({regY:-224,scaleX:1,scaleY:1,x:128,y:41.2},4).wait(181));

	// t1c_png
	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(92,48.2,0.5021,0.5021,0,0,0,-148,-217);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(7).to({_off:false},0).to({regY:-216.8,scaleX:1.2448,scaleY:1.2448,x:91.85},6,cjs.Ease.sineOut).to({regY:-217,scaleX:1,scaleY:1,x:92},4).wait(183));

	// t1b_png
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(62,41.2,0.4175,0.4175,0,0,0,-178,-224);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(5).to({_off:false},0).to({regX:-177.8,regY:-223.8,scaleX:1.2895,scaleY:1.2895,x:62.1,y:41.25},6,cjs.Ease.sineOut).to({regX:-178,regY:-224,scaleX:1,scaleY:1,x:62,y:41.2},4).wait(185));

	// t1a_png
	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(30.95,46.2,0.3939,0.3939,0,0,0,-209.1,-219);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(3).to({_off:false},0).to({regX:-208.9,scaleX:1.1581,scaleY:1.1581,x:30.9,y:46.05},6,cjs.Ease.sineOut).to({regX:-209,scaleX:1,scaleY:1,x:31,y:46.2},5).wait(186));

	// Layer_1
	this.instance_6 = new lib.Tween1("synched",0);
	this.instance_6.setTransform(195,43.2,1,1,0,0,0,-45,-222);

	this.instance_7 = new lib.Tween2("synched",0);
	this.instance_7.setTransform(163,42.2,1,1,0,0,0,-77,-223);

	this.instance_8 = new lib.Tween3("synched",0);
	this.instance_8.setTransform(128,41.2,1,1,0,0,0,-112,-224);

	this.instance_9 = new lib.Tween4("synched",0);
	this.instance_9.setTransform(92,48.2,1,1,0,0,0,-148,-217);

	this.instance_10 = new lib.Tween5("synched",0);
	this.instance_10.setTransform(62,41.2,1,1,0,0,0,-178,-224);

	this.instance_11 = new lib.Tween6("synched",0);
	this.instance_11.setTransform(31,46.2,1,1,0,0,0,-209,-219);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]}).to({state:[]},1).wait(199));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.1,-12.1,642,684);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_21
	this.instance = new lib.Tween12("synched",0);
	this.instance.setTransform(107.2,357.45,0.9936,0.9936,0,0,0,0.1,0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(109).to({_off:false},0).to({alpha:1},9).wait(82));

	// Layer_20
	this.instance_1 = new lib.Tween11("synched",0);
	this.instance_1.setTransform(96.5,376.5,1.7402,1.7402);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(105).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},13,cjs.Ease.sineOut).wait(7).to({startPosition:0},0).to({scaleX:0.9213,scaleY:0.9213},7).to({startPosition:0},3).to({scaleX:1,scaleY:1},4).wait(12).to({startPosition:0},0).to({scaleX:0.9213,scaleY:0.9213},7).to({startPosition:0},3).to({scaleX:1,scaleY:1},4).wait(12).to({startPosition:0},0).to({scaleX:0.9213,scaleY:0.9213},7).to({startPosition:0},3).to({scaleX:1,scaleY:1},4).wait(9));

	// Layer_1
	this.instance_2 = new lib.Tween12("synched",0);
	this.instance_2.setTransform(107.2,357.45,0.9936,0.9936,0,0,0,0.1,0.1);

	this.instance_3 = new lib.Tween11("synched",0);
	this.instance_3.setTransform(96.5,376.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).to({state:[]},1).wait(199));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.1,0,326.1,469);


// stage content:
(lib._320x480 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ghw
	this.instance = new lib.ghwai("synched",0);
	this.instance.setTransform(160,444,1,1,0,0,0,160,36);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(200));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0C0706").s().p("AkiFRIAAqhID9AAQCbABBbBpQBSBfAACHQAACIhSBfQhbBpibABgAh2C0IBRAAQBLAAAtg4QAogzAAhJQAAhIgogyQgtg5hLAAIhRAAg");
	this.shape.setTransform(271.2991,361.7616,0.1143,0.1143);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0C0706").s().p("Ai4FQIAAqgIFoAAIAACaIi9AAIAABgIDDAAIAACYIjDAAIAAB2IDGAAIAACYg");
	this.shape_1.setTransform(252.9599,361.7616,0.1143,0.1143);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0C0706").s().p("ABoFQIAAkOIjPAAIAAEOIiwAAIAAqgICwAAIAAD1IDPAAIAAj1ICwAAIAAKgg");
	this.shape_2.setTransform(244.5563,361.7616,0.1143,0.1143);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0C0706").s().p("ACsFVIgnhVIkJAAIgnBVIioAAID2qpIC5AAID4KpgAhMBtICZAAIhNjig");
	this.shape_3.setTransform(261.5864,361.713,0.1143,0.1143);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0C0706").s().p("ACsFVIgnhVIkJAAIgnBVIioAAID2qpIC5AAID4KpgAhMBtICZAAIhNjig");
	this.shape_4.setTransform(234.9751,361.713,0.1143,0.1143);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0C0706").s().p("AjsEFQhshhAAikQAAikBshhQBhhXCLAAQCMAABhBXQBsBhAACkQAACkhsBhQhhBYiMAAQiLAAhhhYgAhziHQg0AyAABVQAABWA0AzQAvAtBFAAQBEAAAwgtQA0gzAAhWQAAhVg0gyQgwguhEAAQhFAAgvAug");
	this.shape_5.setTransform(212.6028,361.7787,0.1143,0.1143);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0C0706").s().p("AjfEDQhthgAAijQAAihBthgQBhhXCKAAQBgABBLAqQBVAwAkBYIiXA8QgVgrgigTQgigTg0AAQhOAAgtA4QgrAzAABPQAABUAtAyQAuAzBLAAQA2AAAggRQAkgTAWgvIiPAAIAAiUIE+AAQAEA8gEAnQgEA1gPAtQgiBihYAzQhMAshmAAQiLAAhghVg");
	this.shape_6.setTransform(202.7586,361.7558,0.1143,0.1143);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#ED1C24").s().p("ApFMqIgFgHQgQgYgDglQgCglALgqQAJgnAQgZIDnmPQghgFgugPQhegfhJg3QhnhMgthtQgMgdgIgfQgeh1AciSIACgLQAWhtBAhVQA5hMBWg2QBIgsBTgYQBGgUA3AAQB7AABkAeQBQAYA+AqQAsAeAfAkQAPASAGAMQArgsAlgbQAjgZAlgNQAhgMAogDQAggCA1ABQBiAKBNBQQAYAZATAdIAOAYQhwg1hSAPQhDALgrA1QgfAmgRA3QgJAcgCAUIB0OaIBvBoIBnhMIAtBHIkRDKIjNinIgLhgIl1D8IlIj/Ig9BrQAQAaAKAjQAKAlAAAgQgBAagIASQgDAGgFAGQgRAXgjAAQgsAAgXgcgAknEwIFaEPIDXiYIghjeInSAAgAncpAQg6AggtA3QgsA1gWBBQgWBDAGBAQAKBgAmBIQAjBBA4AqQAyAmBAASQA6AQA+gDICUj6QgCgSgJgbQgQg1gdgqQgpg7g7gbQhLghhlATIAJgOQAMgSARgPQA3gxBTgIQAtgEAhABQAnACAhALQBIAXBJBIIAVgfQgHgMgPgSQgfgkgngeQg2gqg+gYQhMgehUgBQhCAAg+AhgAiLAkIFfAAIg/nkg");
	this.shape_7.setTransform(254.6584,337.015,0.914,0.914);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(200));

	// cta
	this.instance_1 = new lib.cta();
	this.instance_1.setTransform(21.7,114.35,0.6478,0.6478);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(200));

	// bm
	this.instance_2 = new lib.bm_1();
	this.instance_2.setTransform(156,227,1,1,0,0,0,160,240);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(200));

	// T1
	this.instance_3 = new lib.T1();
	this.instance_3.setTransform(192.25,214.4,0.7892,0.7892,0,0,0,240,265.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(200));

	// T2
	this.instance_4 = new lib.T2();
	this.instance_4.setTransform(192.25,214.4,0.7892,0.7892,0,0,0,240,265.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(200));

	// tangan1
	this.instance_5 = new lib.tangan1_1();
	this.instance_5.setTransform(105.65,210.5,0.7574,0.7574,0,0,0,128.8,265.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(200));

	// T3
	this.instance_6 = new lib.T3();
	this.instance_6.setTransform(192.25,214.4,0.7892,0.7892,0,0,0,240,265.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(200));

	// T4
	this.instance_7 = new lib.T4();
	this.instance_7.setTransform(192.8,214.85,0.7892,0.7892,0,0,0,240.5,265.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(200));

	// T6
	this.instance_8 = new lib.T6();
	this.instance_8.setTransform(192.25,214.4,0.7892,0.7892,0,0,0,240,265.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(200));

	// tangan2
	this.instance_9 = new lib.tangan2_1();
	this.instance_9.setTransform(190.75,214.3,0.7574,0.7574,0,0,0,240.4,265.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(200));

	// T5
	this.instance_10 = new lib.T5();
	this.instance_10.setTransform(192.25,214.4,0.7892,0.7892,0,0,0,240,265.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(200));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(83.3,227,299.3,253);
// library properties:
lib.properties = {
	id: '89875DAC14343B4689B1CD28EDF293A8',
	width: 320,
	height: 480,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bm.png", id:"bm"},
		{src:"images/bolong.jpg", id:"bolong"},
		{src:"images/BukanMain03.png", id:"BukanMain03"},
		{src:"images/BukanMain04.png", id:"BukanMain04"},
		{src:"images/BukanMain05.png", id:"BukanMain05"},
		{src:"images/BukanMain07.png", id:"BukanMain07"},
		{src:"images/BukanMain08.png", id:"BukanMain08"},
		{src:"images/BukanMain09.png", id:"BukanMain09"},
		{src:"images/BukanMain11.png", id:"BukanMain11"},
		{src:"images/BukanMain13.png", id:"BukanMain13"},
		{src:"images/CTAcopy.png", id:"CTAcopy"},
		{src:"images/t1a.png", id:"t1a"},
		{src:"images/t1b.png", id:"t1b"},
		{src:"images/t1c.png", id:"t1c"},
		{src:"images/t1d.png", id:"t1d"},
		{src:"images/t1e.png", id:"t1e"},
		{src:"images/t1f.png", id:"t1f"},
		{src:"images/t2a.png", id:"t2a"},
		{src:"images/t2b.png", id:"t2b"},
		{src:"images/t2c.png", id:"t2c"},
		{src:"images/t2d.png", id:"t2d"},
		{src:"images/t3a.png", id:"t3a"},
		{src:"images/t3b.png", id:"t3b"},
		{src:"images/t3c.png", id:"t3c"},
		{src:"images/t3d.png", id:"t3d"},
		{src:"images/t4a.png", id:"t4a"},
		{src:"images/t4b.png", id:"t4b"},
		{src:"images/t4c.png", id:"t4c"},
		{src:"images/t5a.png", id:"t5a"},
		{src:"images/t5b.png", id:"t5b"},
		{src:"images/t5c.png", id:"t5c"},
		{src:"images/t5d.png", id:"t5d"},
		{src:"images/t6a.png", id:"t6a"},
		{src:"images/t6b.png", id:"t6b"},
		{src:"images/t6c.png", id:"t6c"},
		{src:"images/t6d.png", id:"t6d"},
		{src:"images/tangan1.png", id:"tangan1"},
		{src:"images/tangan2.png", id:"tangan2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['89875DAC14343B4689B1CD28EDF293A8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;